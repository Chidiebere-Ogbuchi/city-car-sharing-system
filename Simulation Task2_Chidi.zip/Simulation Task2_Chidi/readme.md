# Simulation of Incentive Strategies for Car Rental System - PART ONE

This project simulates various incentive strategies to evaluate their impact on net revenue for a city car-sharing system. The primary goal is to optimize the battery threshold for interventions and free-minute incentives to maximize net revenue.

## Data Files

1. **rental_data.csv**: Contains data on rental transactions, including rental duration, distance, and revenue.
   - `Start` and `End`: Timestamps for the rental start and end times.
   - `Duration`: Calculated in minutes.
   - `Distance`: Distance traveled during the rental (km).
   - `Revenue`: Revenue generated from the rental.

2. **charge_probabilities.csv**: Specifies charging probabilities for users based on different incentives.
   - `Incentive`: Number of free minutes offered as an incentive.
   - `Charging_probability`: Probability that a user will charge their vehicle under the given incentive.

## Simulation Parameters

- **Battery Threshold**: Minimum battery level before an intervention is needed. Configurable between 20% and 30%.
- **Service Team Cost**: Cost of service team intervention set to €6 per intervention.
- **Incentive Cost**: Cost of free minutes given as incentives, set to €0.29 per minute.
- **Battery Consumption**: Battery consumption during a rental is 0.5% per kilometer.
- **Initial Battery**: Initial battery level is set to 100%.
- **Waiting Time**: Time for service team intervention set to 180 minutes.

## Code Breakdown

### Data Preparation

1. **Loading and Preprocessing**:
   - Rental data is loaded and parsed to calculate rental durations.
   - Battery consumption for each rental is calculated based on distance.

2. **Charging Behavior Simulation**:
   - Users charge their vehicles probabilistically based on incentives using data from `charge_probabilities.csv`.

### Simulation Functionality

1. **simulate_user_charging**:
   Simulates whether a user charges their vehicle based on the current battery level and offered incentive.

2. **simulate_battery_level**:
   Iterates through rental transactions to simulate changes in battery levels, service team interventions, and user charging behavior.

### Optimization Process

1. **Cost and Revenue Calculation**:
   - **Total Service Cost**: Number of service team interventions multiplied by the cost per intervention.
   - **Total Incentive Cost**: Number of fully charged vehicles incentivized, multiplied by incentive cost.
   - **Total Cost**: Sum of service and incentive costs.
   - **Net Revenue**: Total revenue from rentals minus the total cost.

2. **Optimization Function**:
   Uses `scipy.optimize.minimize` to determine the optimal combination of battery threshold and incentive levels that maximize net revenue. The function minimizes the negative net revenue to achieve this goal.

### Visualization

1. **Net Revenue vs Incentive**:
   A line plot showing the impact of various incentives on net revenue for different battery thresholds.

2. **Incentive Impact on Revenue**:
   A bar plot showing how incentives affect net revenue across all thresholds.

### Output

- Results of each simulation scenario are saved to `results_revenue.csv`.
- Summary statistics and visualizations are generated to highlight the impact of thresholds and incentives on net revenue.

### Optimal Strategy

The code determines the optimal battery threshold and incentive level using the optimization process. Key metrics include:

- **Optimal Battery Threshold**: Battery level below which intervention is triggered.
- **Optimal Incentive**: Number of free minutes offered to users to incentivize charging.
- **Total Service Cost**: Cost incurred due to service team interventions.
- **Total Incentive Cost**: Cost incurred by offering free minutes.
- **Net Revenue**: Revenue after deducting all costs.

## How to Run

1. Ensure `rental_data.csv` and `charge_probabilities.csv` are available in the working directory.
2. Execute the script to simulate various scenarios and generate results.
3. Review the results in `results_revenue.csv` and visualizations to analyze the impact of incentives and thresholds.

## Key Results

- The optimization identifies the combination of battery threshold and incentives that maximize net revenue.
- Visualizations help understand the trade-offs between service interventions and user charging incentives.

## Dependencies

- Python Libraries:
  - `pandas`
  - `numpy`
  - `matplotlib`
  - `seaborn`
  - `scipy`

Install these libraries using:
```bash
pip install pandas numpy matplotlib seaborn scipy
```





---

# Rental Data Analysis and Revenue Modeling for planning incentive (A/B test variables) - PART TWO

This project analyzes rental data to explore factors impacting revenue in a car-sharing system. It uses regression modeling to identify statistically significant predictors of revenue and visualizations to explore feature relationships.

---

## Table of Contents
1. [Dataset Overview](#dataset-overview)
2. [Key Features Generated](#key-features-generated)
3. [Statistical Modeling](#statistical-modeling)
4. [Visualizations](#visualizations)
5. [Usage](#usage)
6. [Results](#results)
7. [Dependencies](#dependencies)

---

## Dataset Overview

- The dataset includes timestamped information for rental start and end times, distances traveled, battery consumption, and revenue generated.
- Key columns:
  - `Start`, `End`: Timestamps for rental start and end.
  - `Distance`: Distance covered during a rental (in km).
  - `Revenue`: Revenue generated for each rental (in €).
  - `Rental_state`: Rental status (e.g., `'RED'` indicates active rentals).

---

## Key Features Generated

### Derived Features:
1. **Duration**: Rental/idle duration in minutes, calculated as the difference between `End` and `Start`.
2. **Battery_Consumption**: Percentage of battery consumed during rentals (computed for active rentals based on distance traveled).
3. **Is_Peak_Hour**: Binary indicator for whether a rental occurred during peak hours (7-9 AM or 5-7 PM).
4. **Day_of_Week**: Day of the week (0 = Monday, 6 = Sunday) for each rental.

### Standardized Features (for regression):
- `Duration_Standardized`, `Distance_Standardized`, and `Battery_Consumption_Standardized` are standardized versions of respective columns for better interpretability.

---

## Statistical Modeling

- **Objective**: Analyze the impact of various factors on revenue.
- **Regression Formula**:
  ```
  Revenue ~ C(Rental_state) + Duration_Standardized + Distance_Standardized + 
            Battery_Consumption_Standardized + Is_Peak_Hour + C(Day_of_Week)
  ```
  - Categorical variables (`Rental_state`, `Day_of_Week`) are automatically one-hot encoded.
  - Continuous variables are standardized to compare coefficients effectively.

- **Steps**:
  1. Filter rows with non-positive revenue values.
  2. Fit an Ordinary Least Squares (OLS) regression model.
  3. Summarize coefficients, p-values, and confidence intervals.

---

## Visualizations

### Regression Results
- **Feature Coefficients and Confidence Intervals**: Bar plot with confidence intervals to assess the impact and certainty of each feature.
- **P-Values**: Bar plot highlighting statistically significant features (p-value < 0.05).

### Feature Relationships
1. **Revenue vs Duration**: Scatter plot with regression line.
2. **Revenue vs Distance**: Scatter plot with regression line.
3. **Revenue vs Battery Consumption**: Scatter plot with regression line.
4. **Average Revenue by Day of the Week**: Bar chart.
5. **Average Revenue by Hour of the Day**: Line plot.

---

## Usage

1. Ensure the dataset is named `rental_data.csv` and is in the same directory as the script.
2. Install the dependencies listed below.
3. Run the script to generate the regression analysis and visualizations.

---

## Results

### Statistical Significance
- The model outputs a list of features with p-values < 0.05, indicating statistical significance.
- The script also prints and visualizes the importance of features and their relationships to revenue.

### Insights
1. Factors such as rental duration, distance, and peak hour usage influence revenue.
2. Some days of the week or times of day show higher average revenues.

---

## Dependencies

- **Python Libraries**:
  - `pandas`: Data manipulation and feature engineering.
  - `numpy`: Numerical operations.
  - `statsmodels`: Regression analysis.
  - `seaborn` and `matplotlib`: Data visualization.

Install these libraries via pip if not already installed:
```bash
pip install pandas numpy statsmodels seaborn matplotlib
```

---

## Conclusion

This project provides insights into factors affecting car-sharing revenue and identifies significant predictors using statistical modeling. The visualizations offer an intuitive understanding of relationships between features and revenue, aiding decision-making and policy planning.

--- 

